# AS015IW: PROCEDURE ON THE DETERMINATION OF TOTAL MOISTURE IN HARD COAL
## Standard Operating Procedure for Single-Stage and Two-Stage Thermal Drying Methods (ISO 589:2008 / ISO 13909-4:2025)

```
========================================================================================
Document ID:         AS015IW Rev 01
Replaces:            AS015IW Rev 00 (Effective 08/2025)
Document Type:       Controlled Standard Operating Procedure (Type C)
QMS Clause:          ISO/IEC 17025:2017 Clause 7.2 (Selection & Verification of Methods)
Governing Standards: ISO 589:2008 (Hard coal — Determination of total moisture)
                     ISO 13909-4:2025 (Mechanical sampling — Preparation of test samples)
                     ISO 18283:2006 (Manual sampling)
Supporting SOPs:     AS001IW Rev 04 (Hard Coal Sample Preparation Procedure)
Associated Forms:    AS015TF-01 (Raw Data Sheet — Single-Stage Total Moisture)
                     AS015TF-02 (Raw Data Sheet — Two-Stage Total Moisture)
                     AS023TF (Verification Report — Drying Oven)
Assessment Standard: AZCA-015 (Competency Assessment for Total Moisture)
Compiled By:         Tshepo Maponya — Laboratory Supervisor / Technical Signatory
Approved By:         Nonhlanhla Msibi — Operations Manager
Effective Date:      October 2026
Next Review Date:    October 2029
Revision Status:     01
Distribution:        Controlled Document — AzureSky Coal Laboratory
========================================================================================
```

---

## 1. Scope, Principle and Method Selection

### 1.1. Scope
This procedure specifies the methods for determining the total moisture content of hard coal received at AzureSky Coal Laboratory. The procedure applies to run-of-mine (ROM) coal, washed product streams, borehole core samples, and customer consignment samples.

### 1.2. Principle
The total moisture content of coal is determined by measuring the loss in mass when the sample is heated in air at a controlled temperature of **$105\ ^\circ\text{C}$ to $110\ ^\circ\text{C}$** until constant mass is attained.

In accordance with **ISO 589:2008**, AzureSky utilizes thermal drying in air:
* **Method A2 (Two-Stage Thermal Drying in Air)**: For moist or uncrushed bulk coal.
* **Method B2 (Single-Stage Thermal Drying in Air)**: For free-flowing, drier coal crushed directly to $-10\text{ mm}$.

Both methods are fully validated under AzureSky's ISO/IEC 17025 quality management system for coals not susceptible to rapid thermal oxidation.

### 1.3. Method Selection Criteria (Single-Stage vs. Two-Stage)
The analyst must select the correct determination method based on the physical condition and particle top-size of the received coal:

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              METHOD SELECTION DECISION MATRIX                          │
├─────────────────────────┬───────────────────────────────┬──────────────────────────────┤
│ Sample Condition        │ Selection                     │ Technical Justification      │
├─────────────────────────┼───────────────────────────────┼──────────────────────────────┤
│ Visibly wet, dripping,   │ MANDATORY:                    │ Prevents moisture loss by    │
│ or excessively moist;   │ Two-Stage Determination       │ evaporation during milling;  │
│ or bulk top-size >10 mm │ (AS015IW Clauses 2, 3 & 4.1)  │ prevents crusher choking and │
│                         │                               │ screen binding.              │
├─────────────────────────┼───────────────────────────────┼──────────────────────────────┤
│ Free-flowing, dry coal; │ Single-Stage Determination    │ Permits direct oven drying   │
│ nominal top-size        │ (AS015IW Clause 4.2)          │ at -10 mm without intermediate│
│ reduced to -10 mm       │                               │ air-drying delay.            │
└─────────────────────────┴───────────────────────────────┴──────────────────────────────┘
```

> [!IMPORTANT]
> **Mandatory Rule for Wet Samples**: If coal particles adhere together, if water droplets separate inside the sample container, or if milling will cause mechanical choking, a **Two-Stage Determination** is strictly mandatory. Direct crushing of excessively moist coal causes significant, uncontrolled moisture loss, resulting in biased test results.

---

## 2. Sample Reception, Mass and Primary Division

### 2.1. Reception & Incoming Sample Specifications
1. **Traceability**: Upon receipt, record sample details in the Sample Receiving Book and generate a barcode on LIMS.
2. **Maximum Nominal Top-Size Acceptance Limit**:
   * In accordance with [AS001IW Clause 4.1](file:///c:/Projects/AzureSky/Total-Moisture/AS001IW%20PROCEDURE%20ON%20SAMPLE%20PREPARATION%20OF%20HARD%20COAL%20Rev%2004.pdf#L130), the nominal top-size of all bulk samples accepted by the laboratory **shall not exceed $50\text{ mm}$**.
   * Samples exceeding $50\text{ mm}$ top-size must be rejected or reported to the Laboratory Supervisor prior to processing.
3. **Minimum Bulk Sample Mass**:
   * Per **ISO 13909-4:2025 Table 1** and ISO 18283 Table 3, the minimum required mass for a $50\text{ mm}$ nominal top-size sample is **$35\text{ kg}$**.
4. **Primary Division by Cone and Quartering**:
   * Form the bulk coal into an even cone on a clean, non-absorbent sampling floor.
   * Flatten the apex of the cone uniformly.
   * Divide the flattened cone into four equal quarters using a clean dividing board/cross.
   * Select one quarter.
   * **Representativeness Rule**: If the mass of the chosen single quarter is less than the mandatory **$35\text{ kg}$**, the analyst must **combine two opposite quarters** to ensure the minimum sample mass and statistical representativeness are preserved.
5. **Initial "As Received" Mass ($m_1$)**:
   * Immediately weigh the divided bulk sample on the calibrated platform balance to the nearest $0.01\text{ kg}$.
   * Capture and lock $m_1$ on LIMS and log it on [AS015TF-02](file:///c:/Projects/AzureSky/Total-Moisture/AS015TF-02%20Raw%20Data%20Sheet%20-%20Two-Stage%20Total%20Moisture.docx). This is the initial **"As Received"** mass.

---

### 2.2. Stage 1: Air Drying (Free / Surface Moisture)

1. **Spreading**: Spread the $35\text{ kg}$ sample thinly and evenly over clean, dry, tared drying pans. The layer loading shall not exceed $1\text{ g/cm}^2$ per ISO 589 Clause 6.3.1.
2. **Drying Conditions**:
   * Allow the sample to air dry at ambient laboratory temperature or in a dedicated fan-forced air-drying oven at a controlled temperature **not exceeding $40\ ^\circ\text{C}$**.
   * Continue drying until the coal appears **"visibly dry"** and free-flowing.

> [!CAUTION]
> **Temperature Restriction ($\le 40\ ^\circ\text{C}$)**:
> In accordance with ISO 589 Clause 6.1.1 and ISO 13909-4 Clause 9, the air-drying temperature **must strictly NOT exceed $40\ ^\circ\text{C}$**. 
> **Scientific Rationale**: Temperatures above $40\ ^\circ\text{C}$ promote chemisorption of atmospheric oxygen (thermal oxidation), especially in lower-rank and bituminous coals. Oxidation causes an irreversible mass increase of the coal matrix, leading to an artificially lower calculated moisture loss and severe negative analytical bias.

3. **Stage 1 Stability Check**:
   * Re-weigh the pans and sample on the balance and capture weights on LIMS.
   * **Stability Criterion**: Air drying is complete when the mass loss between successive checks is **less than $0.1\text{ g}$** ($< 0.1\text{ g}$).
4. **Final Air-Dried Mass ($m_2$)**:
   * Record the final air-dried sample mass ($m_2$) on LIMS and [AS015TF-02](file:///c:/Projects/AzureSky/Total-Moisture/AS015TF-02%20Raw%20Data%20Sheet%20-%20Two-Stage%20Total%20Moisture.docx).

---

## 3. Sub-Sampling and Comminution (Crushing Sequence)

### 3.1. Crushing Sequence
To prevent moisture loss from internal heating and air displacement, comminution must be executed rapidly using validated jaw crushers. Grinding mills must never be used.

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                             CRUSHING AND DIVISION SEQUENCE                             │
├────────────────────────────────────────────────────────────────────────────────────────┤
│ 1. Primary Crush       │ Pass air-dried coal through the 25 mm crusher.                │
├────────────────────────┼───────────────────────────────────────────────────────────────┤
│ 2. Intermediate Split  │ Reduce mass using a clean, properly sized Riffle Splitter.    │
├────────────────────────┼───────────────────────────────────────────────────────────────┤
│ 3. Secondary Crush     │ • For Single-Stage: Crush sample to -10 mm.                  │
│                        │ • For Two-Stage:    Crush sample to -3 mm.                   │
├────────────────────────┼───────────────────────────────────────────────────────────────┤
│ 4. Final Division      │ Riffle split to obtain duplicate 1 kg portions.              │
└────────────────────────┴───────────────────────────────────────────────────────────────┘
```

### 3.2. Final Preparation of Duplicate Pans
1. **Riffling**: Pass the crushed coal through the riffle splitter to achieve sub-samples of **$1\text{ kg}$ per riffled side**.
2. **Pan Preparation & Taring**: Prepare two clean, dry, numbered moisture pans. Tare each pan on the LIMS-interfaced analytical balance.
3. **Sample Transfer**: Transfer approximately $1\text{ kg}$ into **Pan A** and $1\text{ kg}$ into **Pan B**.
4. **Initial Mass Capture ($m_3$)**: Record the exact initial mass ($m_3$) on LIMS for both Pan A and Pan B immediately to prevent ambient moisture re-equilibration.

---

## 4. Oven Drying (Residual and Single-Stage Moisture)

### 4.1. Two-Stage Residual Moisture ($-3\text{ mm}$ Coal)

```mermaid
flowchart TD
    A["Prepare Duplicate Pans (Pan A & Pan B, 1 kg each at -3 mm)"] --> B["Record Tare & Net Mass m3 on LIMS"]
    B --> C["Place in Preheated Oven at 105 °C - 110 °C"]
    C --> D["Initial Drying: 3.0 Hours continuous"]
    D --> E["First Weighing: Capture mass on LIMS"]
    E --> F["Return pans to Oven for 30 minutes"]
    F --> G["Re-weigh: Calculate 30-min mass loss Δm"]
    G --> H{"Is Δm ≤ 0.1 g?"}
    H -->|Yes| I["Sample Stable: Capture final mass m4 on LIMS"]
    H -->|No| J{"Total oven time ≥ 5.0 hours?"}
    J -->|No| F
    J -->|Yes| K["TEST FAILED: Mark Failed in LIMS. Repeat Test!"]
```

1. **Oven Operating Conditions**:
   * Pre-heat the drying oven to **$105\ ^\circ\text{C}$ to $110\ ^\circ\text{C}$** (nominal operating setpoint: $\le 107\ ^\circ\text{C}$).
   * Ensure ventilation and forced air circulation meet ISO 589 requirements (minimum 5 atmosphere changes per hour).
2. **Initial Drying Interval**:
   * Place Pan A and Pan B into the oven and dry continuously for **3 hours**.
3. **First Weighing**:
   * Remove pans after 3 hours. Capture the mass on LIMS immediately.
   * Return pans to the oven for an additional **30 minutes**.
4. **Stability Criteria**:
   * Remove pans and re-weigh.
   * Calculate mass loss between consecutive 30-minute intervals: $\Delta m = m_{\text{previous}} - m_{\text{current}}$.
   * If mass loss between consecutive 30-minute intervals is **$\le 0.1\text{ g}$**, the sample is declared **"stable"**, signaling completion of drying.
5. **Final Stabilized Mass ($m_4$)**:
   * Capture final stable mass ($m_4$) on LIMS for Pan A and Pan B.
6. **Maximum Oven Failure Threshold**:
   * **Failure Limit**: If the sample fails to stabilize within **$5\text{ hours}$** of total oven residence time, the test is automatically marked as **"Failed"** in LIMS.
   * **Mandatory Corrective Action**: The analysis is invalidated. The analyst must investigate potential oven temperature fluctuations or air-seal leaks, obtain a backup split from the $-3\text{ mm}$ retained sample, and **repeat the oven determination in full**.

---

### 4.2. Single-Stage Moisture ($-10\text{ mm}$ Coal)

1. **Applicability**: Free-flowing, dry coal samples prepared directly to $-10\text{ mm}$ nominal top-size without prior air drying.
2. **Sample Mass**: Weigh duplicate $1\text{ kg}$ portions into clean, tared pans (Pan A and Pan B).
3. **Oven Residence Time**:
   * Place pans in the preheated oven at **$105\ ^\circ\text{C}$ to $110\ ^\circ\text{C}$**.
   * The sample remains in the oven for the **full 5-hour duration continuously**, without the 3-hour intermediate check used in the two-stage method.
4. **Weighing Protocol**:
   * Per ISO 589 Clause 8.2.1, remove pans after 5 hours and weigh as soon as possible (**within 5 minutes**), while still warm, to prevent moisture adsorption from ambient room air during cooling.
5. **Stabilized Mass**:
   * Capture the final stabilized mass ($m_3$ in single-stage notation) on LIMS and [AS015TF-01](file:///c:/Projects/AzureSky/Total-Moisture/AS015TF-01%20Raw%20Data%20Sheet%20-%20Single-Stage%20Total%20Moisture.docx).

---

## 5. Calculations and Mathematical Formulas

> [!IMPORTANT]
> **Moisture Definition**: Moisture content is always a measure of **mass loss** during thermal drying. In all mathematical equations, the initial mass must precede the dried mass in the numerator to ensure positive percentage values.

### 5.1. Surface (Free / Air-Dry) Moisture ($M_{ar}$)
Calculated from Stage 1 air drying:

$$M_{ar} = \left( \frac{m_1 - m_2}{m_1} \right) \times 100$$

Where:
* $m_1$ = Initial mass of bulk coal sample as received ($kg$).
* $m_2$ = Mass of bulk coal sample after Stage 1 air drying ($kg$).

**Worked Example**:
* Initial as-received mass ($m_1$) = $35.00\text{ kg}$
* Final air-dried mass ($m_2$) = $32.55\text{ kg}$
$$M_{ar} = \left( \frac{35.00 - 32.55}{35.00} \right) \times 100 = \left( \frac{2.45}{35.00} \right) \times 100 = 7.00\%$$

---

### 5.2. Residual Moisture ($M_{res}$)
Calculated from Stage 2 oven drying for each duplicate pan:

$$M_{res} = \left( \frac{m_3 - m_4}{m_3} \right) \times 100$$

Where:
* $m_3$ = Mass of $-3\text{ mm}$ sample before oven drying ($1\text{ kg}$ net charge, in $g$).
* $m_4$ = Final stabilized mass of sample after oven drying ($g$).

Calculate residual moisture separately for both duplicate pans:
* **Pan A**: $M_{res,A} = \left( \frac{m_{3,A} - m_{4,A}}{m_{3,A}} \right) \times 100$
* **Pan B**: $M_{res,B} = \left( \frac{m_{3,B} - m_{4,B}}{m_{3,B}} \right) \times 100$

---

### 5.3. Total Moisture ($TM$) for Two-Stage Determination

#### 5.3.1. Standard Two-Stage Moisture Equation (ISO 589 Equation 3)
For each individual pan, Total Moisture is calculated as:

$$TM = M_{ar} + \frac{(100 - M_{ar}) \times M_{res}}{100}$$

#### 5.3.2. LIMS Implementation vs. ISO 589 Alignment
* **ISO 589 Calculation Flow**: Calculates $TM_A$ for Pan A and $TM_B$ for Pan B individually, then averages the two values:
  $$TM_{\text{report}} = \frac{TM_A + TM_B}{2}$$
* **AzureSky LIMS Calculation Flow**: Averages the duplicate residual moistures first ($M_{res,\text{avg}} = \frac{M_{res,A} + M_{res,B}}{2}$) and inserts $M_{res,\text{avg}}$ directly into the total moisture equation:
  $$TM_{\text{LIMS}} = M_{ar} + \frac{(100 - M_{ar}) \times M_{res,\text{avg}}}{100}$$

> [!NOTE]
> **Mathematical Equivalence**: 
> Because the equation is linear with respect to residual moisture:
> $$\frac{TM_A + TM_B}{2} = \frac{\left(M_{ar} + \frac{(100 - M_{ar})M_{res,A}}{100}\right) + \left(M_{ar} + \frac{(100 - M_{ar})M_{res,B}}{100}\right)}{2} = M_{ar} + \frac{(100 - M_{ar}) \left(\frac{M_{res,A} + M_{res,B}}{2}\right)}{100}$$
> Both methods produce identical numerical results. Both methods are formally approved at AzureSky and comply with ISO 589:2008.

---

### 5.4. Total Moisture ($TM$) for Single-Stage Determination (ISO 589 Equation 5)

$$TM = \left( \frac{m_2 - m_3}{m_2 - m_1} \right) \times 100$$

Where:
* $m_1$ = Tare mass of empty, dry pan ($g$).
* $m_2$ = Gross mass of pan + sample before oven drying ($g$).
* $m_3$ = Gross mass of pan + sample after 5-hour oven drying ($g$).

---

## 6. Precision, Repeatability Limits and Quality Control

### 6.1. Repeatability and Reproducibility Limits (ISO 589 Table 1)

```
┌───────────────────────────────────────┬──────────────────────┬────────────────────────┐
│ Property                              │ Repeatability Limit  │ Reproducibility Limit  │
│                                       │ (r, Same Lab / Tech) │ (R, Different Labs)    │
├───────────────────────────────────────┼──────────────────────┼────────────────────────┤
│ Second-Stage Moisture (M_res)         │ 0.30 %               │ Not Applicable         │
│ Total Moisture (TM) — Single/Two-Stage│ 0.50 %               │ 1.50 %                 │
└───────────────────────────────────────┴──────────────────────┴────────────────────────┘
```

### 6.2. LIMS Repeat Alert & Out-of-Specification Action
1. **Second-Stage Repeatability Check**:
   $$\Delta M_{res} = |M_{res,A} - M_{res,B}|$$
   * If $\Delta M_{res} \le 0.30\%$: The test complies with ISO 589 repeatability. The mean is calculated and approved.
   * If $\Delta M_{res} > 0.30\%$: LIMS automatically flags a **"REPEAT ALERT"**.
2. **Total Moisture Repeatability Check**:
   $$\Delta TM = |TM_A - TM_B|$$
   * If $\Delta TM > 0.50\%$: The test exceeds the total moisture repeatability limit.
3. **Mandatory Action on Repeat Alert**:
   * The test result is invalidated.
   * Results must not be released to the client.
   * The analyst must perform a root cause review (check for pan spillage, balance calibration drift, or uneven oven loading).
   * Re-riffle a fresh duplicate pair of $1\text{ kg}$ portions from the retained sample and repeat the oven drying determination.

---

## 7. Equipment Metrology and Verification Controls

To ensure metrological traceability under ISO/IEC 17025 Clause 6.4, all testing equipment must comply with the following mandatory verification schedules:

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              MANDATORY EQUIPMENT VERIFICATIONS                         │
├─────────────────────┬───────────────────────────┬──────────────────────────────────────┤
│ Equipment           │ Verification Frequency    │ Acceptance Criteria & Reference      │
├─────────────────────┼───────────────────────────┼──────────────────────────────────────┤
│ Moisture Oven       │ Daily before use          │ Calibrated thermocouple reading      │
│                     │                           │ (Average + Correction Factor) within │
│                     │                           │ 105 °C to 110 °C. Setpoint ≤ 107 °C  │
│                     │                           │ (Ref: AS023TF).                      │
├─────────────────────┼───────────────────────────┼──────────────────────────────────────┤
│ Coarse Crushers     │ Every Monday at the start │ Sieve screening efficiency check on  │
│ (25 mm and 10 mm)   │ of shift before work      │ crushed product (Ref: AS001IW Cl. 4.1)│
├─────────────────────┼───────────────────────────┼──────────────────────────────────────┤
│ Fine Crushers       │ Day of use, immediately   │ Sieve screening efficiency check on  │
│ (3 mm and 4.75 mm)  │ before using the crusher  │ crushed product (Ref: AS001IW Cl. 4.1)│
├─────────────────────┼───────────────────────────┼──────────────────────────────────────┤
│ Analytical & Heavy  │ Daily before use          │ Calibrated check weights (1000.0 g   │
│ Balances            │                           │ tolerance ± 0.1 g).                  │
└─────────────────────┴───────────────────────────┴──────────────────────────────────────┘
```

---

## 8. Summary of Critical Assessment Requirements (AZCA-015 Reference)

For technicians undergoing technical competency assessment under **[AZCA-015](file:///c:/Projects/AzureSky/Total-Moisture/AZCA-015%20Assessment%20for%20Total%20Moisture_DRAFT.docx.doc)**:

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                            ZERO-TOLERANCE ASSESSMENT CRITERIA                          │
├────────────────────────────────────────────────────────────────────────────────────────┤
│ Qualifying Threshold: Minimum 80% (16 / 20 points).                                   │
│                                                                                        │
│ MANDATORY CRITICAL GATE 1 (Question *5): Procedural Flow & Crushing                   │
│ Candidate must state all 5 sequential steps with 100% precision:                       │
│   1. Spread 35 kg sample thinly on pans until visibly dry (≤ 40 °C).                   │
│   2. Stage 1 stability check: mass loss < 0.1 g.                                       │
│   3. Primary crush through 25 mm crusher and reduce mass with Riffle Splitter.         │
│   4. Secondary crush to -10 mm (Single-Stage) or -3 mm (Two-Stage).                    │
│   5. Final riffle division to 1 kg per side, tare pans, transfer to Pan A and Pan B.   │
│                                                                                        │
│ MANDATORY CRITICAL GATE 2 (Question *6): Oven Temperature & Stability Timing           │
│ Candidate must state:                                                                  │
│   • Oven operating temperature range: 105 °C to 110 °C.                                │
│   • Two-stage initial drying: 3 hours.                                                 │
│   • Interval re-weighing: 30 minutes.                                                  │
│   • Stability criterion: mass loss between 30-min intervals ≤ 0.1 g.                   │
│                                                                                        │
│ ⚠️ FAILURE RULE: If Question *5 or Question *6 is answered incorrectly, the assessment │
│ is immediately terminated, and the candidate is declared NOT YET COMPETENT.            │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 9. Revision History Table

| Revision No. | Effective Date | Reason for Revision & Key Changes | Author / Approval |
| :---: | :---: | :--- | :--- |
| **00** | 08/2025 | Initial creation and implementation of laboratory test procedure. | T. Maponya / N. Msibi |
| **01** | 10/2026 | Comprehensive harmonization with ISO 589:2008 and ISO 13909-4:2025:<br>1. Corrected calculation formula numerator order ($m_1 - m_2$ and $m_3 - m_4$).<br>2. Added explicit decision criteria for Single vs Two-Stage method selection.<br>3. Formally incorporated incoming coal top-size limit ($\le 50\text{ mm}$) and $35\text{ kg}$ minimum bulk mass.<br>4. Added scientific oxidation rationale for Stage 1 temperature limit ($\le 40\ ^\circ\text{C}$).<br>5. Clarified 5-step crushing flow, 5-hour oven failure threshold, and single-stage continuous drying.<br>6. Incorporated equipment verification schedules from AS023TF and AS001IW.<br>7. Aligned with AZCA-015 assessment zero-tolerance gates. | T. Maponya / N. Msibi |
