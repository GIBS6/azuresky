# AZCA-015: OPERATOR STUDY & EXAM PREPARATION GUIDE
## Determination of Total Moisture in Hard Coal (Single-Stage & Two-Stage)

```
========================================================================================
Training Module:      AZCA-015 Technical Competency
Target SOP:           AS015IW Rev 01 (Determination of Total Moisture)
Governing Standards:  ISO 589:2008 | ISO 13909-4:2025 | ISO 17025:2017
Pass Mark:            80% (16 / 20 points) + 100% on Critical Questions (*5 and *6)
Critical Gate Policy: ZERO-TOLERANCE on Q5 and Q6 (Immediate stoppage if incorrect)
Target Audience:      Coal Laboratory Analysts, Preparation Technicians, Technical Signatories
========================================================================================
```

---

## 1. Quick Overview: Why and How We Measure Total Moisture

Coal moisture directly impacts commercial valuation, energy content (Calorific Value), transport costs, and plant handling.

```
Total Moisture (TM) = Surface (Free) Moisture (Stage 1) + Residual Moisture (Stage 2)
```

* **Surface (Free) Moisture ($M_{ar}$)**: Water on the exterior surface of coal particles. Measured by air drying bulk coal at low temperature ($\le 40\ ^\circ\text{C}$).
* **Residual Moisture ($M_{res}$)**: Water retained inside the coal pores and capillaries. Measured by oven drying $-3\text{ mm}$ coal at $105\ ^\circ\text{C} - 110\ ^\circ\text{C}$.
* **Single-Stage Moisture**: Direct oven drying of $-10\text{ mm}$ coal for 5 hours when coal is already dry and free-flowing.

---

## 2. THE TWO ZERO-TOLERANCE CRITICAL QUESTIONS

> [!CAUTION]
> **ASSESSMENT STOPPAGE RULE**: In AZCA-015, if you miss even one detail in Question 5 or Question 6, the test stops immediately and you receive a **NOT YET COMPETENT** grade. Memorize these two questions thoroughly.

---

### Critical Question *5: The 5-Step Procedural Sequence (5 Points — Must be 100% Correct)

You must be able to list these **5 steps in exact sequential order**:

```
Step 1: Spread 35 kg sample thinly on clean drying pans until "visibly dry" 
        (at ambient room temperature or fan-forced oven ≤ 40 °C).

Step 2: Perform Stage 1 stability check on LIMS: air drying is complete when 
        consecutive mass loss is < 0.1 g.

Step 3: Primary crush the air-dried coal through the 25 mm crusher, then reduce 
        mass using the Riffle Splitter.

Step 4: Secondary crush the sample:
        • Crush to -10 mm for Single-Stage determination, OR
        • Crush to -3 mm for Two-Stage determination.

Step 5: Final division using the Riffle Splitter to achieve 1 kg per side, 
        tare moisture pans on the balance, and transfer into duplicate 
        Pan A and Pan B.
```

---

### Critical Question *6: Oven Temperature & Stability Timing (1 Point — Must be 100% Correct)

You must state the exact numbers:

```
1. Exact Operating Temperature Range:
   105 °C to 110 °C (Nominal setpoint ≤ 107 °C)

2. Initial Drying Duration:
   Dry continuously for 3 hours before first weighing.

3. Subsequent Drying Intervals:
   Return pans to the oven for 30 minutes at a time.

4. Stability Criterion:
   The sample is stable when the mass loss between consecutive 30-minute intervals 
   is ≤ 0.1 g (or less than 0.1 g).
```

---

## 3. High-Yield Question Guide: Questions 1 to 12

### Question 1: Method Selection (2 pts)
* **What are the two methods?** Single-Stage and Two-Stage thermal drying.
* **When is Two-Stage mandatory?** When coal is **visibly wet, dripping, or excessively moist**, or when the particle size/bulk mass makes direct crushing prone to moisture loss by evaporation or mechanical choking/blinding of the crusher.

### Question 2: Sample Mass & Top-Size (1 pt)
* **Minimum sample mass for $50\text{ mm}$ top-size**: **$35\text{ kg}$** (per ISO 13909-4 Table 1).
* **Maximum nominal top-size accepted by the lab**: **$\le 50\text{ mm}$** (per AS001IW Cl. 4.1).

### Question 3: Cone & Quartering Rule (2 pts)
* **Procedure**: Form coal into a cone, flatten the top, divide into four equal quarters, select one quarter.
* **If mass $< 35\text{ kg}$**: Combine **two opposite quarters** to ensure statistical representativeness.

### Question 4: Stage 1 Temperature & Oxidation Rationale (1 pt)
* **Temperature limit**: Ambient or fan-forced oven **$\le 40\ ^\circ\text{C}$**.
* **Why not $> 40\ ^\circ\text{C}$?** High temperatures accelerate **thermal oxidation** of coal. Oxidation causes atmospheric oxygen to chemically bond to the coal, causing **mass gain**, which artificially suppresses calculated moisture loss and leads to severe negative analytical bias.

### Question 7: Oven Failure Limit (1 pt)
* **Maximum allowable drying time**: **5 hours**.
* **Mandatory Action**: If sample fails to stabilize within 5 hours, LIMS marks the test as **"Failed"**. The test is invalidated and must be completely repeated with a backup split.

### Question 8: Single-Stage vs Two-Stage Oven Drying (1 pt)
* In **Single-Stage ($-10\text{ mm}$)**, the coal stays in the oven for the **full 5-hour duration continuously** without any 3-hour check. It is removed and weighed hot within 5 minutes.

### Question 9: Equipment Verification Controls (1 pt)
* **Moisture Oven ([AS023TF](file:///c:/Projects/AzureSky/Total-Moisture/AS023TF-ISO%20MOISTURE%20OVEN%20VERIFICATION%20-.pdf))**: Daily verified using a calibrated thermocouple ($\text{Average Reading} + \text{Correction Factor}$) within $105\ ^\circ\text{C} - 110\ ^\circ\text{C}$ (indicator setpoint $\le 107\ ^\circ\text{C}$).
* **Crusher Efficiency ([AS001IW](file:///c:/Projects/AzureSky/Total-Moisture/AS001IW%20PROCEDURE%20ON%20SAMPLE%20PREPARATION%20OF%20HARD%20COAL%20Rev%2004.pdf))**:
  * Coarse crushers ($25\text{ mm}$ and $10\text{ mm}$): **Every Monday before shift commences**.
  * Fine crushers ($3\text{ mm}$ and $4.75\text{ mm}$): **On the day of use before use**.

### Question 10: Surface (Free) Moisture Calculation (2 pts)
* **Formula**:
  $$M_{ar} = \left(\frac{m_1 - m_2}{m_1}\right) \times 100$$
* **Calculation with given numbers**:
  * $m_1 = 35.00\text{ kg}$ (as received)
  * $m_2 = 32.55\text{ kg}$ (air dried)
  $$M_{ar} = \left(\frac{35.00 - 32.55}{35.00}\right) \times 100 = \left(\frac{2.45}{35.00}\right) \times 100 = 7.00\%$$

### Question 11: Repeatability Limits & LIMS Repeat Alert (2 pts)
* **Given**: Pan A $M_{res} = 4.20\%$, Pan B $M_{res} = 4.58\%$.
* **Difference**: $|4.58\% - 4.20\%| = 0.38\%$.
* **Compliance**: **DOES NOT COMPLY**. The repeatability limit for 2nd stage moisture is **$0.30\%$**.
* **LIMS Alert & Action**: LIMS triggers a **"REPEAT ALERT"**. The duplicate result is invalidated, and the analyst must re-split and re-run the oven determination.

### Question 12: LIMS vs. ISO 589 Calculation Alignment (1 pt)
* **Difference**:
  * **AzureSky LIMS**: Averages the duplicate residual moistures first ($M_{res,\text{avg}}$) and plugs it directly into the $TM$ formula.
  * **ISO 589 Standard**: Calculates $TM$ for Pan A and Pan B separately, then averages them at the very end.
* **Are both accepted?** **YES**. Mathematically they yield identical results because the equation is linear. Both are fully approved under AzureSky QMS.

---

## 4. Self-Test Scoring Matrix (Mock Test)

Use this rubric to test yourself before taking the official AZCA-015 assessment:

| Question | Topic | Max Points | Passing Requirement |
| :---: | :--- | :---: | :--- |
| **Q1** | Method Selection (Single vs Two Stage) | 2 | Both methods (1 pt), wet coal reason (1 pt) |
| **Q2** | Min Mass & Max Top Size | 1 | $35\text{ kg}$ (0.5 pt), $\le 50\text{ mm}$ (0.5 pt) |
| **Q3** | Cone & Quartering Rule | 2 | 4 quarters (1 pt), 2 opposite quarters if $< 35\text{ kg}$ (1 pt) |
| **Q4** | Air-Drying Temp & Oxidation Rationale | 1 | $\le 40\ ^\circ\text{C}$ (0.5 pt), oxidation bias rationale (0.5 pt) |
| **Q5\*** | **CRITICAL: 5-Step Procedural Sequence** | **5\*** | **ALL 5 steps correct in order (Zero tolerance!)** |
| **Q6\*** | **CRITICAL: Temp & Stability Timing** | **1\*** | **$105 - 110\ ^\circ\text{C}$, $3\text{ h}$, $30\text{ min}$, $\le 0.1\text{ g}$ (Zero tolerance!)** |
| **Q7** | Max Oven Time & Failure Action | 1 | $5\text{ hours}$ (0.5 pt), mark Failed & repeat (0.5 pt) |
| **Q8** | Single-Stage Oven Residence | 1 | Full $5\text{ hours}$ continuous (1 pt) |
| **Q9** | Equipment Verification Schedules | 1 | Oven thermocouple (0.5 pt), crusher schedule (0.5 pt) |
| **Q10** | Free Moisture Formula & Math | 2 | Formula (1 pt), correct calculation to $7.00\%$ (1 pt) |
| **Q11** | Repeatability Check & LIMS Alert | 2 | $0.38\% > 0.30\%$ fails (1 pt), repeat alert & re-test (1 pt) |
| **Q12** | LIMS vs ISO 589 Formula Alignment | 1 | Explain averaging difference & confirm equivalence (1 pt) |
| **TOTAL** | | **20** | **Minimum 16 / 20 (80%) AND 100% on Q5 & Q6** |
